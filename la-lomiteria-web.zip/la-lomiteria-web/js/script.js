// ======================================
// LA LOMITERÍA
// Archivo principal de JavaScript
// Versión 2.0
// ======================================

// ---------- DATOS DEL NEGOCIO ----------
const negocio = {
  nombre: "La Lomitería",
  tagline: "Sandwichería premium",
  whatsapp: "5493489576094", // 549 + 3489 (Campana) + 576094
  telefonoVisible: "3489-576094",
  direccion: "Güemes 773, Campana",
  instagram: "lalo.miteria",
  horario: "Miércoles a lunes, de 20 a 23:30"
};

// ---------- DATOS DEL MENÚ ----------
// El lomo lleva pan árabe y la pachata pan ciabatta — misma receta, elegís el pan al pedir.
// Todos los precios incluyen papas. Actualizar acá cuando cambie la carta: el HTML no se toca.
const menuData = [
  {
    nombre: "Radical",
    descripcion: "Bifes de lomo, queso tybo o cheddar + papas.",
    precios: { 100: 9750, 200: 18300, 300: 27100 },
    imagen: "assets/images/lomito-radical.jpg"
  },
  {
    nombre: "Especial",
    descripcion: "Bifes de lomo, queso tybo, jamón cocido y tomate + papas.",
    precios: { 100: 10700, 200: 19500, 300: 28900 },
    imagen: "assets/images/lomito-especial.jpg"
  },
  {
    nombre: "Especial c/Huevo",
    descripcion: "Bifes de lomo, queso tybo, jamón natural, tomate y huevo a la plancha + papas.",
    precios: { 100: 11300, 200: 20000, 300: 29500 },
    imagen: "assets/images/lomito-especial-huevo.jpg"
  },
  {
    nombre: "Americano",
    descripcion: "Bifes de lomo, queso cheddar, panceta ahumada, tomate y huevo a la plancha + papas.",
    precios: { 100: 11300, 200: 20000, 300: 29500 },
    imagen: "assets/images/lomito-americano.jpg"
  },
  {
    nombre: "4 Quesos",
    descripcion: "Bifes de lomo, queso cheddar, tybo, azul y provolone + papas.",
    precios: { 100: 12000, 200: 21000, 300: 31000 },
    imagen: "assets/images/lomito-4-quesos.jpg"
  },
  {
    nombre: "De la Casa",
    descripcion: "Bifes de lomo, queso cheddar, tybo, jamón natural, panceta, tomate y huevo a la plancha + papas.",
    precios: { 100: 12000, 200: 21000, 300: 31000 },
    imagen: "assets/images/lomito-de-la-casa.jpg"
  }
];

function formatPrecio(numero) {
  return "$" + numero.toLocaleString("es-AR");
}

document.addEventListener("DOMContentLoaded", () => {
  document.documentElement.classList.add("js-enabled");

  initWhatsappOrders();
  initMenu();
  initScrollReveal();
  initFooterYear();
});

// ======================================
// PEDIDOS POR WHATSAPP
// ======================================
function buildWhatsappUrl(mensaje) {
  return `https://wa.me/${negocio.whatsapp}?text=${encodeURIComponent(mensaje)}`;
}

function initWhatsappOrders() {
  document.querySelectorAll("[data-whatsapp-order]").forEach((boton) => {
    boton.addEventListener("click", (evento) => {
      evento.preventDefault();
      const item = boton.getAttribute("data-whatsapp-order");
      const mensaje =
        item && item !== "general"
          ? `Hola ${negocio.nombre}! Quiero pedir: ${item}. Gracias.`
          : `Hola ${negocio.nombre}! Quiero hacer un pedido. Gracias.`;
      window.open(buildWhatsappUrl(mensaje), "_blank", "noopener");
    });
  });
}

// ======================================
// MENÚ DINÁMICO
// ======================================
function initMenu() {
  const grid = document.getElementById("menu-grid");
  if (!grid) return;

  grid.innerHTML = "";

  menuData.forEach((item) => {
    const card = document.createElement("article");
    card.className = "menu-item";

    const imagenHtml = item.imagen
      ? `<img class="menu-item-img" src="${item.imagen}" alt="${item.nombre}" loading="lazy" width="1200" height="675">`
      : `<div class="menu-item-img menu-item-img--placeholder" aria-hidden="true"></div>`;

    const preciosHtml = Object.entries(item.precios)
      .map(([gramos, precio]) => `
        <div class="ticket-stub-row">
          <span class="ticket-label">${gramos} gr</span>
          <span class="ticket-value">${formatPrecio(precio)}</span>
        </div>
      `)
      .join("");

    card.innerHTML = `
      ${imagenHtml}
      <div class="menu-item-body">
        <h3 class="menu-item-name">${item.nombre}</h3>
        <p class="menu-item-desc">${item.descripcion}</p>
        <div class="menu-item-precios">${preciosHtml}</div>
        <a href="#" class="btn btn-ghost" data-whatsapp-order="${item.nombre}">Pedir este</a>
      </div>
    `;
    grid.appendChild(card);
  });

  // los botones se crean en este render: hay que engancharlos
  initWhatsappOrders();
}

// ======================================
// ANIMACIÓN AL HACER SCROLL
// Progresiva: si JS no corre, el CSS deja todo visible por defecto.
// ======================================
function initScrollReveal() {
  const elementos = document.querySelectorAll(".reveal");
  if (!("IntersectionObserver" in window)) {
    elementos.forEach((el) => el.classList.add("in-view"));
    return;
  }

  const observador = new IntersectionObserver(
    (entradas) => {
      entradas.forEach((entrada) => {
        if (entrada.isIntersecting) {
          entrada.target.classList.add("in-view");
          observador.unobserve(entrada.target);
        }
      });
    },
    { threshold: 0.15 }
  );

  elementos.forEach((el) => observador.observe(el));
}

// ======================================
// AÑO EN EL FOOTER
// ======================================
function initFooterYear() {
  const el = document.getElementById("year");
  if (el) el.textContent = new Date().getFullYear();
}
